from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout, get_backends
from django.contrib.auth.decorators import login_required
from .forms import UserRegisterForm, TransactionForm, BudgetForm
from .models import Transaction, Budget
from django.db.models import Sum
from datetime import datetime
import calendar
from decimal import Decimal

def custom_google_login(request):
    return render(request, 'google_login.html')

def home(request):
    if request.user.is_authenticated:
        return redirect('dashboard')
    return render(request, 'home.html')

def register_view(request):
    if request.method == 'POST':
        form = UserRegisterForm(request.POST)
        if form.is_valid():
            user = form.save()

            # Set backend explicitly to avoid ValueError with multiple backends
            backend = get_backends()[0]
            user.backend = f"{backend.__module__}.{backend.__class__.__name__}"

            login(request, user)
            return redirect('dashboard')
    else:
        form = UserRegisterForm()
    return render(request, 'register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user:
            login(request, user)
            return redirect('dashboard')
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def dashboard(request):
    transactions = Transaction.objects.filter(user=request.user).order_by('-date')
    income = transactions.filter(transaction_type='income').aggregate(Sum('amount'))['amount__sum'] or 0
    expenses = transactions.filter(transaction_type='expense').aggregate(Sum('amount'))['amount__sum'] or 0
    savings = income - expenses
    return render(request, 'dashboard.html', {
        'income': income,
        'expenses': expenses,
        'savings': savings,
        'transactions': transactions,
    })

@login_required
def add_transaction(request):
    if request.method == 'POST':
        form = TransactionForm(request.POST, request.FILES)
        if form.is_valid():
            txn = form.save(commit=False)
            txn.user = request.user
            txn.save()
            return redirect('dashboard')
    else:
        form = TransactionForm()
    return render(request, 'add_transaction.html', {'form': form})

@login_required
def edit_transaction(request, pk):
    txn = get_object_or_404(Transaction, pk=pk, user=request.user)
    if request.method == 'POST':
        form = TransactionForm(request.POST, request.FILES, instance=txn)
        if form.is_valid():
            form.save()
            return redirect('dashboard')
    else:
        form = TransactionForm(instance=txn)
    return render(request, 'edit_transaction.html', {'form': form, 'txn': txn})

@login_required
def delete_transaction(request, pk):
    txn = get_object_or_404(Transaction, pk=pk, user=request.user)
    if request.method == 'POST':
        txn.delete()
        return redirect('dashboard')
    return render(request, 'delete_transaction.html', {'txn': txn})

@login_required
def manage_budget(request):
    current_month = datetime.now().month
    current_year = datetime.now().year

    if request.method == 'POST':
        form = BudgetForm(request.POST)
        if form.is_valid():
            budget = form.save(commit=False)
            budget.user = request.user
            budget.save()
            return redirect('manage_budget')
    else:
        form = BudgetForm()

    budgets = Budget.objects.filter(user=request.user, month=current_month, year=current_year)

    actuals = Transaction.objects.filter(
        user=request.user,
        transaction_type='expense',
        date__month=current_month,
        date__year=current_year
    ).values('category').annotate(total=Sum('amount'))

    actual_map = {entry['category']: entry['total'] for entry in actuals}

    for b in budgets:
        b.spent = actual_map.get(b.category, Decimal('0.00')) or Decimal('0.00')
        b.remaining = b.amount - b.spent
        b.status = 'under' if b.spent <= b.amount else 'over'
        b.percent = round((b.spent / b.amount) * 100, 2) if b.amount > 0 else 0

    return render(request, 'manage_budget.html', {
        'form': form,
        'budgets': budgets,
        'month': current_month,
        'year': current_year
    })

@login_required
def report_view(request):
    current_year = datetime.now().year
    selected_month = int(request.GET.get('month', datetime.now().month))
    selected_year = int(request.GET.get('year', current_year))

    transactions = Transaction.objects.filter(
        user=request.user,
        date__month=selected_month,
        date__year=selected_year
    )

    income = transactions.filter(transaction_type='income').aggregate(Sum('amount'))['amount__sum'] or 0
    expenses = transactions.filter(transaction_type='expense').aggregate(Sum('amount'))['amount__sum'] or 0
    savings = income - expenses

    months = [(i, calendar.month_name[i]) for i in range(1, 13)]

    return render(request, 'report.html', {
        'transactions': transactions,
        'income': income,
        'expenses': expenses,
        'savings': savings,
        'selected_month': selected_month,
        'selected_year': selected_year,
        'year_range': range(current_year - 5, current_year + 6),
        'months': months,
    })

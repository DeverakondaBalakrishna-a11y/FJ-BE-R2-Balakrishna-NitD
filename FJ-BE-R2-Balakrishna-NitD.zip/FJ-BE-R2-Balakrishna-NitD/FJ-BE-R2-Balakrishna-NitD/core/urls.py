from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),

    path('register/', views.register_view, name='register'),
    path('google-login/', views.custom_google_login, name='custom_google_login'),
    path('login/',    views.login_view,    name='login'),
    path('logout/',   views.logout_view,   name='logout'),

    path('dashboard/',       views.dashboard,        name='dashboard'),
    path('add/',             views.add_transaction,  name='add_transaction'),
    path('edit/<int:pk>/',   views.edit_transaction, name='edit_transaction'),
    path('delete/<int:pk>/', views.delete_transaction, name='delete_transaction'),

    path('budgets/',         views.manage_budget,    name='manage_budget'),
    path('report/', views.report_view, name='report'),
    
]

from django.db import models
from django.contrib.auth.models import User

# Constants
TRANSACTION_TYPES = (
    ('income', 'Income'),
    ('expense', 'Expense'),
)

CATEGORY_CHOICES = (
    ('salary', 'Salary'),
    ('freelance', 'Freelance'),
    ('investment', 'Investment'),
    ('food', 'Food'),
    ('transport', 'Transport'),
    ('entertainment', 'Entertainment'),
    ('health', 'Health'),
    ('utilities', 'Utilities'),
    ('other', 'Other'),
)

# Transaction Model
class Transaction(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    transaction_type = models.CharField(max_length=10, choices=TRANSACTION_TYPES)
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    date = models.DateField()
    description = models.TextField(blank=True, null=True)
    receipt = models.FileField(upload_to='receipts/', null=True, blank=True)

    def __str__(self):
        return f"{self.transaction_type.title()} - {self.category} - ₹{self.amount}"

# Budget Model
class Budget(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    category = models.CharField(max_length=50, choices=CATEGORY_CHOICES)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    month = models.IntegerField()
    year = models.IntegerField()

    def __str__(self):
        return f"{self.user.username} - {self.category} Budget - ₹{self.amount} ({self.month}/{self.year})"

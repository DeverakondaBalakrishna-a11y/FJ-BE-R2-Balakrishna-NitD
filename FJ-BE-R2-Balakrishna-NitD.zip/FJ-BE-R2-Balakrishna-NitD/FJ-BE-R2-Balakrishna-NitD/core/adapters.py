from allauth.socialaccount.adapter import DefaultSocialAccountAdapter
from allauth.exceptions import ImmediateHttpResponse
from django.shortcuts import redirect
from django.contrib.auth import get_user_model
from allauth.account.utils import perform_login

User = get_user_model()

class MySocialAccountAdapter(DefaultSocialAccountAdapter):
    def pre_social_login(self, request, sociallogin):
        # If user is already logged in, do nothing
        if request.user.is_authenticated:
            return

        email = sociallogin.user.email
        if email:
            existing_user = User.objects.filter(email=email).first()
            if existing_user:
                # Auto-connect the social account
                sociallogin.connect(request, existing_user)
                # Auto-login
                perform_login(request, existing_user, email_verification='optional')
                # Skip the intermediate screen
                raise ImmediateHttpResponse(redirect('dashboard'))

    def is_auto_signup_allowed(self, request, sociallogin):
        """
        Auto-signup allowed for all users without intermediate confirmation.
        """
        return True
